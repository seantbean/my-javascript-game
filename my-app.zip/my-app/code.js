var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["78c460ae-738b-428f-8a04-c4f60eea5866","1477e06a-4383-42cc-bf8d-1730dd6cfb3b"],"propsByKey":{"78c460ae-738b-428f-8a04-c4f60eea5866":{"name":"hi","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"jw2zrSwbXRh52VMX0KgdnHUhi2fCxVTl","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/78c460ae-738b-428f-8a04-c4f60eea5866.png"},"1477e06a-4383-42cc-bf8d-1730dd6cfb3b":{"name":"beanz","sourceUrl":"assets/v3/animations/Oc2QLu1KPAossSsb7YV3mZ3PQ8Lvy6NHMyEL6GJWotg/1477e06a-4383-42cc-bf8d-1730dd6cfb3b.png","frameSize":{"x":256,"y":144},"frameCount":1,"looping":true,"frameDelay":4,"version":"5KLf7ew2zTwgdWALXs1tZUlHy8Cikdzm","loadedFromSource":true,"saved":true,"sourceSize":{"x":256,"y":144},"rootRelativePath":"assets/v3/animations/Oc2QLu1KPAossSsb7YV3mZ3PQ8Lvy6NHMyEL6GJWotg/1477e06a-4383-42cc-bf8d-1730dd6cfb3b.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = true;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

background("green");
fill("blue");
rect(0, 300, 400, 100);
fill("red");
rect(0, 250, 50, 50);
rect(50, 200, 50, 50);
rect(100, 150, 50, 50);
rect(150, 100, 100, 50);
rect(250, 150, 50, 50);
rect(300, 200, 50, 50);
rect(350, 250, 50, 50);
fill("black");
rect(150, 150, 100, 400);
textSize(25);
text("bridge", 150, 25);
text("beanz r cool", 250, 50);
function draw() {
  var  hi = createSprite(180, 50);
  hi.setAnimation("hi");
  var beanz = createSprite(300, 100);
  beanz.setAnimation("beanz");
  beanz.width = 75;
  beanz.height = 50;
  beanz.rotation = beanz.rotation + randomNumber(1, 10);
  hi.y = hi.y + randomNumber(1, 10);
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
